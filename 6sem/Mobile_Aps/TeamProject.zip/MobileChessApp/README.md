# MobileChessApp

Creators
- author: Maurycy Sosnowski
- author: Wojciech Gabryelski

Description:
- A simple mobile chess-app project,
made for mobile app development course on PWR.

Technologies used:
- Android Studio
- Kotlin
- ...
