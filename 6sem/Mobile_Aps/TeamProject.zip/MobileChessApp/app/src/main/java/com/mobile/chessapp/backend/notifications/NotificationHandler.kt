package com.mobile.chessapp.backend.notifications

class NotificationHandler {
    // TODO ...
}