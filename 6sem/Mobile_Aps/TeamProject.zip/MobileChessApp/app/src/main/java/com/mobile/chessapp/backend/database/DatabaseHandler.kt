package com.mobile.chessapp.backend.database

class DatabaseHandler {
    // TODO ...
}