package com.mobile.chessapp.activities

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class AnalyzeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }
}