package socketServer;

/**
 * Class that runs the server
 * @author Maurycy Sosnowski
 * @author Gosia Orlowska
 *
 */
public class Trylma {
    public static void main( String[] args ) throws Exception {
        new TrylmaServerWindow();
    }
}
