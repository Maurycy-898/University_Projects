package clientServer;

import static org.junit.Assert.assertTrue;

import org.junit.Test;
import socketClient.SocketClient;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Scanner;

import static org.mockito.Mockito.*;

public class ClientTest {

    @Test
    public void checkPlayMethod() throws IOException {
    assertTrue(true);
    }

}
