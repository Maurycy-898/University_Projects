//Autor: Maurycy Sosnowski

#include <stdio.h>
#include <float.h>

int main() {
    printf("\n%e\n%e\n\n", FLT_EPSILON, DBL_EPSILON);
    printf("%e\n%e\n", FLT_MAX, DBL_MAX);
}