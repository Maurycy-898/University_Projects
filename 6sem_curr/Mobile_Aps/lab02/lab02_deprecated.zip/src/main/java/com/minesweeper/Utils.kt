package com.minesweeper

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView


//---------------------- CONST VALUES --------------------------------------------------------------
const val BOMB: Int = -1
const val BLANK: Int = 0

//---------------------- RECYCLER ADAPTER ----------------------------------------------------------
class GridRecyclerAdapter(
    private var cells: List<Cell>,
    private val listener: OnCellClickListener
) : RecyclerView.Adapter<GridRecyclerAdapter.MineTileViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MineTileViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.item_cell, parent, false)
        return MineTileViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: MineTileViewHolder, position: Int) {
        holder.bind(cells[position])
        holder.setIsRecyclable(false)
    }

    override fun getItemCount(): Int {
        return cells.size
    }

    fun refreshCells(newCells: List<Cell>) {
        this.cells = newCells
        notifyDataSetChanged()
    }

    inner class MineTileViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val valueTextView: TextView = itemView.findViewById(R.id.item_cell_value)

        fun bind(cell: Cell) {
            itemView.setBackgroundColor(Color.DKGRAY)
            itemView.setOnClickListener { listener.onCellClick(cell) }

            if (cell.isRevealed) {
                when (cell.value) {
                    BOMB -> {
                        valueTextView.setText(R.string.bomb)
                        itemView.setBackgroundColor(Color.RED)
                    }
                    BLANK -> {
                        valueTextView.text = ""
                        itemView.setBackgroundColor(Color.LTGRAY)
                    }
                    else -> {
                        valueTextView.text = cell.value.toString()
                        itemView.setBackgroundColor(Color.GRAY)
                        when (cell.value) {
                            1 -> { valueTextView.setTextColor(Color.CYAN) }
                            2 -> { valueTextView.setTextColor(Color.GREEN) }
                            3 -> { valueTextView.setTextColor(Color.MAGENTA) }
                        }
                    }
                }
            } else if (cell.isFlagged) {
                valueTextView.setText(R.string.flag)
            }
        }
    }
}

//---------------------- GAME CELL -----------------------------------------------------------------
class Cell(var value: Int) {
    var isRevealed: Boolean = false
    var isFlagged: Boolean = false
}

//---------------------- CELL GRID -----------------------------------------------------------------
class MineGrid(private val size: Int) {
    val cells = ArrayList<Cell>()

    init {
        for (i in 0 until(size * size)) {
            cells.add(Cell(BLANK))
        }
    }

    fun generateGrid(totalBombs: Int) {
        val bombs = List(size * size) { it }.shuffled().subList(0, totalBombs)
        bombs.forEach { bombIdx -> cells[bombIdx].value = BOMB }

        cells.forEachIndexed { idx, cell ->
            val xy = toXY(idx)
            if (cellAt(xy.first, xy.second)!!.value != BOMB) {
                val adjacentCells = adjacentCells(xy.first, xy.second)
                var bombsCounter = 0
                adjacentCells.forEach { c -> if (c.value == BOMB) { bombsCounter++ } }

                if (bombsCounter > 0) {
                    cell.value = bombsCounter
                }
            }
        }
    }

    fun revealAllBombs() {
        cells.forEach { cell -> if (cell.value == BOMB) cell.isRevealed = true }
    }

    fun adjacentCells(x: Int, y: Int): List<Cell> {
        val cellsList: MutableList<Cell> = ArrayList()
        cellAt((x - 1), y)?.let { cellsList.add(it) }
        cellAt((x + 1), y)?.let { cellsList.add(it) }
        cellAt((x - 1), (y - 1))?.let { cellsList.add(it) }
        cellAt(x, (y - 1))?.let { cellsList.add(it) }
        cellAt((x + 1), (y - 1))?.let { cellsList.add(it) }
        cellAt((x - 1), (y + 1))?.let { cellsList.add(it) }
        cellAt(x, (y + 1))?.let { cellsList.add(it) }
        cellAt(x + 1, y + 1)?.let { cellsList.add(it) }
        return cellsList
    }

    fun toXY(index: Int) : Pair<Int, Int> {
        val y = index / size
        val x = index - (y * size)
        return Pair(x, y)
    }

    private fun cellAt(x: Int, y: Int): Cell? {
        return if ((x < 0) || (x >= size) || (y < 0) || (y >= size)) { null
        } else cells[x + y * size]
    }
}

//---------------------- GAME CLASS ----------------------------------------------------------------
class MineSweeperGame(size: Int, val numberBombs: Int) {
    val mineGrid = MineGrid(size)
    var timeExpired = false
    var gameOver = false
    var flagMode = false
    var clearMode = true
    var flagCount = 0

    init { mineGrid.generateGrid(numberBombs) }

    fun handleCellClick(cell: Cell) {
        if (!gameOver && !timeExpired && !cell.isRevealed && !isGameWon()) {
            if (clearMode) { clear(cell) } else if (flagMode) { flag(cell) }
        }
    }

    private fun clear(cell: Cell) {
        val index = mineGrid.cells.indexOf(cell)
        mineGrid.cells[index].isRevealed = true

        if (cell.value == BOMB) {
            gameOver = true
        }
        else if (cell.value == BLANK) {
            val toClear: MutableList<Cell> = ArrayList()
            val toCheckAdjacents: MutableList<Cell> = ArrayList()

            toCheckAdjacents.add(cell)
            while (toCheckAdjacents.size > 0) {
                val c = toCheckAdjacents[0]
                val cellIndex = mineGrid.cells.indexOf(c)
                val cellXY = mineGrid.toXY(cellIndex)
                for (adjacent in mineGrid.adjacentCells(cellXY.first, cellXY.second)) {
                    if (adjacent.value == BLANK) {
                        if (!toClear.contains(adjacent)) {
                            if (!toCheckAdjacents.contains(adjacent)) {
                                toCheckAdjacents.add(adjacent)
                            }
                        }
                    } else {
                        if (!toClear.contains(adjacent)) {
                            toClear.add(adjacent)
                        }
                    }
                }
                toCheckAdjacents.remove(c)
                toClear.add(c)
            }

            toClear.forEach { it.isRevealed = true }
        }
    }

    private fun flag(cell: Cell) {
        if (cell.isFlagged) flagCount-- else flagCount++
        cell.isFlagged = !cell.isFlagged
    }

    fun isGameWon(): Boolean {
        mineGrid.cells.forEach {c ->
            if (c.value != BOMB && c.value != BLANK && !c.isRevealed) {
                return false
            }
        }
        return true
    }

    fun toggleMode() {
        clearMode = !clearMode
        flagMode = !flagMode
    }
}

//---------------------- CELL CLICK ----------------------------------------------------------------
interface OnCellClickListener {
    fun onCellClick(cell: Cell)
}
