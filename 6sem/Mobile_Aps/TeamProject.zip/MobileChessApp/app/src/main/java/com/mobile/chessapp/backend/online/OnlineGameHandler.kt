package com.mobile.chessapp.backend.online

class OnlineGameHandler {
    // TODO ...
}