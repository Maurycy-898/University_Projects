package com.minesweeper

import android.graphics.Color
import android.os.Bundle
import android.os.CountDownTimer
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView


const val TIMER_LENGTH = 999000L
const val BOMB_COUNT = 9
const val GRID_SIZE = 9

class MainActivity : AppCompatActivity(), OnCellClickListener {
    private lateinit var mineGridRecyclerAdapter: GridRecyclerAdapter
    private lateinit var grid: RecyclerView
    private lateinit var smiley: TextView
    private lateinit var timer: TextView
    private lateinit var flag: TextView
    private lateinit var flagsLeft: TextView
    private lateinit var mineSweeperGame: MineSweeperGame
    private lateinit var countDownTimer: CountDownTimer

    private var secondsElapsed = 0
    private var timerStarted = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        grid = findViewById(R.id.activity_main_grid)
        grid.layoutManager = GridLayoutManager(this, GRID_SIZE)

        timer = findViewById(R.id.activity_main_timer)
        timerStarted = false
        countDownTimer = object: CountDownTimer(TIMER_LENGTH, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                secondsElapsed += 1
                timer.text = String.format("%03d", secondsElapsed)
            }

            override fun onFinish() {
                mineSweeperGame.timeExpired
                Toast.makeText(applicationContext, "Game Over: Timer Expired", Toast.LENGTH_SHORT)
                    .show()
                mineSweeperGame.mineGrid.revealAllBombs()
                mineGridRecyclerAdapter.refreshCells(mineSweeperGame.mineGrid.cells)
            }
        }

        flagsLeft = findViewById(R.id.activity_main_flagsleft)
        mineSweeperGame = MineSweeperGame(GRID_SIZE, BOMB_COUNT)
        flagsLeft.text = String.format("%03d", mineSweeperGame.numberBombs - mineSweeperGame.flagCount)
        mineGridRecyclerAdapter = GridRecyclerAdapter(mineSweeperGame.mineGrid.cells, this)
        grid.adapter = mineGridRecyclerAdapter

        smiley = findViewById(R.id.activity_main_smiley)
        smiley.setOnClickListener {
            mineSweeperGame = MineSweeperGame(GRID_SIZE, BOMB_COUNT)
            mineGridRecyclerAdapter.refreshCells(mineSweeperGame.mineGrid.cells)
            timerStarted = false
            countDownTimer.cancel()
            secondsElapsed = 0
            timer.setText(R.string.count)
            flagsLeft.text = String.format("%03d", mineSweeperGame.numberBombs - mineSweeperGame.flagCount)
        }

        flag = findViewById(R.id.activity_main_flag)
        flag.setOnClickListener {
            mineSweeperGame.toggleMode()
            if (mineSweeperGame.flagMode) {
                flag.setBackgroundColor(Color.LTGRAY)
            } else {
                flag.setBackgroundColor(Color.WHITE)
            }
        }
    }

    override fun onCellClick(cell: Cell) {
        mineSweeperGame.handleCellClick(cell)
        flagsLeft.text = String.format("%03d", mineSweeperGame.numberBombs - mineSweeperGame.flagCount)

        if (!timerStarted) {
            countDownTimer.start()
            timerStarted = true
        }
        if (mineSweeperGame.gameOver) {
            countDownTimer.cancel()
            Toast.makeText(applicationContext, "Game Over", Toast.LENGTH_SHORT).show()
            mineSweeperGame.mineGrid.revealAllBombs()
        }
        if (mineSweeperGame.isGameWon()) {
            countDownTimer.cancel()
            Toast.makeText(applicationContext, "Game Won", Toast.LENGTH_SHORT).show()
            mineSweeperGame.mineGrid.revealAllBombs()
        }

        mineGridRecyclerAdapter.refreshCells(mineSweeperGame.mineGrid.cells)
    }
}
